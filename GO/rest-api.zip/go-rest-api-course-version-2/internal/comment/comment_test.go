package comment

import "testing"

func TestGetComment(t *testing.T) {
	t.Run("testing get comments happy path", func(t *testing.T) {

	})

	t.Run("testing get comments sad path", func(t *testing.T) {

	})
}

func TestDeleteComment(t *testing.T) {
	t.Run("testing delete comment happy path", func(t *testing.T) {

	})

	t.Run("testing delete comment sad path", func(t *testing.T) {

	})
}

func TestPostComment(t *testing.T) {
	t.Run("testing post comment happy path", func(t *testing.T) {

	})

	t.Run("testing post comment sad path", func(t *testing.T) {

	})
}

func TestUpdateComment(t *testing.T) {
	t.Run("testing update comment happy path", func(t *testing.T) {

	})

	t.Run("testing update comment sad path", func(t *testing.T) {

	})
}
