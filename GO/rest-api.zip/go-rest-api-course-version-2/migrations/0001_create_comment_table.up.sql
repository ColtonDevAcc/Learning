CREATE TABLE IF NOT EXISTS comments (
    ID uuid,
    Slug text,
    Author text,
    Body text
);